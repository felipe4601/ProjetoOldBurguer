package br.com.oldburguer.Old.Burguer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OldBurguerApplicationTests {

	@Test
	void contextLoads() {
	}

}
