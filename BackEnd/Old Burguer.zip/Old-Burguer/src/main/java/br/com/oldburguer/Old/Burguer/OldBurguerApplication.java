package br.com.oldburguer.Old.Burguer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OldBurguerApplication {

	public static void main(String[] args) {
		SpringApplication.run(OldBurguerApplication.class, args);
	}

}
